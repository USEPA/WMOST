#Wmodel.mod

set time := {1..365} ordered;
param QRuU11{t in time} >=0;
param QRuU21{t in time} >=0;
param QRuU31{t in time} >=0;
param QRuU41{t in time} >=0;
param QRuU51{t in time} >=0;
param QRuU61{t in time} >=0;
param QRuU71{t in time} >=0;
param QRuU81{t in time} >=0;
param QRuU91{t in time} >=0;
param QRuU101{t in time} >=0;
param QRuU12{t in time} >=0;
param QRuU22{t in time} >=0;
param QRuU32{t in time} >=0;
param QRuU42{t in time} >=0;
param QRuU52{t in time} >=0;
param QRuU62{t in time} >=0;
param QRuU72{t in time} >=0;
param QRuU82{t in time} >=0;
param QRuU92{t in time} >=0;
param QRuU102{t in time} >=0;
param QRuU13{t in time} >=0;
param QRuU23{t in time} >=0;
param QRuU33{t in time} >=0;
param QRuU43{t in time} >=0;
param QRuU53{t in time} >=0;
param QRuU63{t in time} >=0;
param QRuU73{t in time} >=0;
param QRuU83{t in time} >=0;
param QRuU93{t in time} >=0;
param QRuU103{t in time} >=0;
param QRuU14{t in time} >=0;
param QRuU24{t in time} >=0;
param QRuU34{t in time} >=0;
param QRuU44{t in time} >=0;
param QRuU54{t in time} >=0;
param QRuU64{t in time} >=0;
param QRuU74{t in time} >=0;
param QRuU84{t in time} >=0;
param QRuU94{t in time} >=0;
param QRuU104{t in time} >=0;
param QRuU15{t in time} >=0;
param QRuU25{t in time} >=0;
param QRuU35{t in time} >=0;
param QRuU45{t in time} >=0;
param QRuU55{t in time} >=0;
param QRuU65{t in time} >=0;
param QRuU75{t in time} >=0;
param QRuU85{t in time} >=0;
param QRuU95{t in time} >=0;
param QRuU105{t in time} >=0;
param QRuU16{t in time} >=0;
param QRuU26{t in time} >=0;
param QRuU36{t in time} >=0;
param QRuU46{t in time} >=0;
param QRuU56{t in time} >=0;
param QRuU66{t in time} >=0;
param QRuU76{t in time} >=0;
param QRuU86{t in time} >=0;
param QRuU96{t in time} >=0;
param QRuU106{t in time} >=0;
param QReU11{t in time} >=0;
param QReU21{t in time} >=0;
param QReU31{t in time} >=0;
param QReU41{t in time} >=0;
param QReU51{t in time} >=0;
param QReU61{t in time} >=0;
param QReU71{t in time} >=0;
param QReU81{t in time} >=0;
param QReU91{t in time} >=0;
param QReU101{t in time} >=0;
param QReU12{t in time} >=0;
param QReU22{t in time} >=0;
param QReU32{t in time} >=0;
param QReU42{t in time} >=0;
param QReU52{t in time} >=0;
param QReU62{t in time} >=0;
param QReU72{t in time} >=0;
param QReU82{t in time} >=0;
param QReU92{t in time} >=0;
param QReU102{t in time} >=0;
param QReU13{t in time} >=0;
param QReU23{t in time} >=0;
param QReU33{t in time} >=0;
param QReU43{t in time} >=0;
param QReU53{t in time} >=0;
param QReU63{t in time} >=0;
param QReU73{t in time} >=0;
param QReU83{t in time} >=0;
param QReU93{t in time} >=0;
param QReU103{t in time} >=0;
param QReU14{t in time} >=0;
param QReU24{t in time} >=0;
param QReU34{t in time} >=0;
param QReU44{t in time} >=0;
param QReU54{t in time} >=0;
param QReU64{t in time} >=0;
param QReU74{t in time} >=0;
param QReU84{t in time} >=0;
param QReU94{t in time} >=0;
param QReU104{t in time} >=0;
param QReU15{t in time} >=0;
param QReU25{t in time} >=0;
param QReU35{t in time} >=0;
param QReU45{t in time} >=0;
param QReU55{t in time} >=0;
param QReU65{t in time} >=0;
param QReU75{t in time} >=0;
param QReU85{t in time} >=0;
param QReU95{t in time} >=0;
param QReU105{t in time} >=0;
param QReU16{t in time} >=0;
param QReU26{t in time} >=0;
param QReU36{t in time} >=0;
param QReU46{t in time} >=0;
param QReU56{t in time} >=0;
param QReU66{t in time} >=0;
param QReU76{t in time} >=0;
param QReU86{t in time} >=0;
param QReU96{t in time} >=0;
param QReU106{t in time} >=0;
param QUsePI1{t in time} >=0;
param QUsePI2{t in time} >=0;
param PUseNp2{t in time} >=0;
param PConsUseP2{t in time} >=0;
param FPUse2{t in time} >=0;
param PConsUseNp2{t in time} >=0;
param FNpUse2{t in time} >=0;
param PConsUsePI2{t in time} >=0;
param QResPt{t in time} >=0;
param QPtRes{t in time} >=0;
param QPtSw{t in time} >=0;
param QPtGw{t in time} >=0;
param QSwPt{t in time} >=0;
param QGwPt{t in time} >=0;
param QExtSw{t in time} >=0;
param QExtGw{t in time} >=0;
param LRuU111{t in time} >=0;
param LRuU211{t in time} >=0;
param LRuU311{t in time} >=0;
param LRuU411{t in time} >=0;
param LRuU511{t in time} >=0;
param LRuU611{t in time} >=0;
param LRuU711{t in time} >=0;
param LRuU811{t in time} >=0;
param LRuU911{t in time} >=0;
param LRuU1011{t in time} >=0;
param LRuU121{t in time} >=0;
param LRuU221{t in time} >=0;
param LRuU321{t in time} >=0;
param LRuU421{t in time} >=0;
param LRuU521{t in time} >=0;
param LRuU621{t in time} >=0;
param LRuU721{t in time} >=0;
param LRuU821{t in time} >=0;
param LRuU921{t in time} >=0;
param LRuU1021{t in time} >=0;
param LRuU131{t in time} >=0;
param LRuU231{t in time} >=0;
param LRuU331{t in time} >=0;
param LRuU431{t in time} >=0;
param LRuU531{t in time} >=0;
param LRuU631{t in time} >=0;
param LRuU731{t in time} >=0;
param LRuU831{t in time} >=0;
param LRuU931{t in time} >=0;
param LRuU1031{t in time} >=0;
param LRuU141{t in time} >=0;
param LRuU241{t in time} >=0;
param LRuU341{t in time} >=0;
param LRuU441{t in time} >=0;
param LRuU541{t in time} >=0;
param LRuU641{t in time} >=0;
param LRuU741{t in time} >=0;
param LRuU841{t in time} >=0;
param LRuU941{t in time} >=0;
param LRuU1041{t in time} >=0;
param LRuU151{t in time} >=0;
param LRuU251{t in time} >=0;
param LRuU351{t in time} >=0;
param LRuU451{t in time} >=0;
param LRuU551{t in time} >=0;
param LRuU651{t in time} >=0;
param LRuU751{t in time} >=0;
param LRuU851{t in time} >=0;
param LRuU951{t in time} >=0;
param LRuU1051{t in time} >=0;
param LRuU161{t in time} >=0;
param LRuU261{t in time} >=0;
param LRuU361{t in time} >=0;
param LRuU461{t in time} >=0;
param LRuU561{t in time} >=0;
param LRuU661{t in time} >=0;
param LRuU761{t in time} >=0;
param LRuU861{t in time} >=0;
param LRuU961{t in time} >=0;
param LRuU1061{t in time} >=0;
param LReU111{t in time} >=0;
param LReU211{t in time} >=0;
param LReU311{t in time} >=0;
param LReU411{t in time} >=0;
param LReU511{t in time} >=0;
param LReU611{t in time} >=0;
param LReU711{t in time} >=0;
param LReU811{t in time} >=0;
param LReU911{t in time} >=0;
param LReU1011{t in time} >=0;
param LReU121{t in time} >=0;
param LReU221{t in time} >=0;
param LReU321{t in time} >=0;
param LReU421{t in time} >=0;
param LReU521{t in time} >=0;
param LReU621{t in time} >=0;
param LReU721{t in time} >=0;
param LReU821{t in time} >=0;
param LReU921{t in time} >=0;
param LReU1021{t in time} >=0;
param LReU131{t in time} >=0;
param LReU231{t in time} >=0;
param LReU331{t in time} >=0;
param LReU431{t in time} >=0;
param LReU531{t in time} >=0;
param LReU631{t in time} >=0;
param LReU731{t in time} >=0;
param LReU831{t in time} >=0;
param LReU931{t in time} >=0;
param LReU1031{t in time} >=0;
param LReU141{t in time} >=0;
param LReU241{t in time} >=0;
param LReU341{t in time} >=0;
param LReU441{t in time} >=0;
param LReU541{t in time} >=0;
param LReU641{t in time} >=0;
param LReU741{t in time} >=0;
param LReU841{t in time} >=0;
param LReU941{t in time} >=0;
param LReU1041{t in time} >=0;
param LReU151{t in time} >=0;
param LReU251{t in time} >=0;
param LReU351{t in time} >=0;
param LReU451{t in time} >=0;
param LReU551{t in time} >=0;
param LReU651{t in time} >=0;
param LReU751{t in time} >=0;
param LReU851{t in time} >=0;
param LReU951{t in time} >=0;
param LReU1051{t in time} >=0;
param LReU161{t in time} >=0;
param LReU261{t in time} >=0;
param LReU361{t in time} >=0;
param LReU461{t in time} >=0;
param LReU561{t in time} >=0;
param LReU661{t in time} >=0;
param LReU761{t in time} >=0;
param LReU861{t in time} >=0;
param LReU961{t in time} >=0;
param LReU1061{t in time} >=0;
param LExtGw1{t in time} >=0;
param LPtGw1{t in time} >=0;
param LPtRes1{t in time} >=0;
param LExtSw1{t in time} >=0;
param LPtSw1{t in time} >=0;
var DALu11 >=3671.87105109647 <=3671.87105109647 :=3671.87105109647;
var DALu21 >=592.695154233215 <=592.695154233215 :=592.695154233215;
var DALu31 >=624.968503164712 <=624.968503164712 :=624.968503164712;
var DALu41 >=150.502043436881 <=150.502043436881 :=150.502043436881;
var DALu51 >=179.983920503973 <=179.983920503973 :=179.983920503973;
var DALu61 >=52.5941112698915 <=52.5941112698915 :=52.5941112698915;
var DALu71 >=134.672109478118 <=134.672109478118 :=134.672109478118;
var DALu81 >=49.3121370972651 <=49.3121370972651 :=49.3121370972651;
var DALu91 >=1175.38776952941 <=1175.38776952941 :=1175.38776952941;
var DALu101 >=14.2975580197957 <=14.2975580197957 :=14.2975580197957;
var DALu12 >=0 <=3658.29842600789;
var DALu22 >=0 <=590.583611782668;
var DALu32 >=0 <=624.816320427386;
var DALu42 >=0 <=150.459977104807;
var DALu52 >=0 <=179.983920503973;
var DALu62 >=0 <=52.5941112698915;
var DALu72 >=0 <=134.672109478118;
var DALu82 >=0 <=49.3121370972651;
var DALu92 >=0 <=0;
var DALu102 >=0 <=0;
var DALu13 >=0 <=3599.44255379126;
var DALu23 >=0 <=581.428539853037;
var DALu33 >=0 <=614.268154446509;
var DALu43 >=0 <=147.544254462926;
var DALu53 >=0 <=178.629679228674;
var DALu63 >=0 <=52.4238725937096;
var DALu73 >=0 <=134.672109478118;
var DALu83 >=0 <=49.3121370972651;
var DALu93 >=0 <=0;
var DALu103 >=0 <=0;
var DALu14 >=0 <=3671.38472027669;
var DALu24 >=0 <=592.601942023914;
var DALu34 >=0 <=624.757953038931;
var DALu44 >=0 <=150.461688514687;
var DALu54 >=0 <=179.983920503973;
var DALu64 >=0 <=52.5941112698915;
var DALu74 >=0 <=134.672109478118;
var DALu84 >=0 <=49.3121370972651;
var DALu94 >=0 <=0;
var DALu104 >=0 <=0;
var DALu15 >=0 <=3645.95703235658;
var DALu25 >=0 <=588.664129350782;
var DALu35 >=0 <=620.612272308768;
var DALu45 >=0 <=149.297894681262;
var DALu55 >=0 <=169.948831787449;
var DALu65 >=0 <=51.3326224572046;
var DALu75 >=0 <=134.672109478118;
var DALu85 >=0 <=49.3121370972651;
var DALu95 >=0 <=0;
var DALu105 >=0 <=0;
var DALu16 >=0 <=3671.3810983294;
var DALu26 >=0 <=592.601247826271;
var DALu36 >=0 <=624.802100645949;
var DALu46 >=0 <=150.470150030631;
var DALu56 >=0 <=179.983920503973;
var DALu66 >=0 <=52.5941112698915;
var DALu76 >=0 <=134.672109478118;
var DALu86 >=0 <=49.3121370972651;
var DALu96 >=0 <=0;
var DALu106 >=0 <=0;

var DQSwExt{t in time} >=0;
var DQGwExt{t in time} >=0;
var DQGwWtp{t in time} >=0;
var DQIbtWUseNp{t in time} >=0;
var DQIbtWUseP{t in time} >=0;
var DQResAsr{t in time} >=0;
var DQResWtp{t in time} >=0;
var DQSwAsr{t in time} >=0;
var DQSwWtp{t in time} >=0;
var DQUseNpIbtWw{t in time} >=0;
var DQUsePIbtWw{t in time} >=0;
var DQWMake{t in time} >=0;
var DQGwMake{t in time} >=0;
var DQGwFlex{t in time} >=0 <=0.001;
var DQWFlex{t in time} >=0 <=0.001;
var DQWrfUseNp{t in time} >=0;
var DQWtpUseNp{t in time} >=0;
var DQWrfAsr{t in time} >=0;
var DQWwtpWrf{t in time} >=0;
var QRu{t in time} >=0;
var QRe{t in time} >=0;
var QSepGw{t in time} >=0;
var QWtpUseP{t in time} >=0;
var QWwtpSw{t in time} >=0;
var QWrfSw{t in time} >=0;
var QAsrGw{t in time} >=0;
var VGw{t in time} >=0 :=757.082357826406;
var QUsePMin{t in time} >=0;
var QUseNpMin{t in time} >=0;
var QSwRes{t in time} >=0;
var VRes{t in time} >=0;
var QGwSw{t in time} >=0;
var QStSSw{t in time} >=0;
var DQUsePSanS{t in time} >=0;
var DQUseNpSanS{t in time} >=0;

var LRu1{t in time} >=0;
var LRe1{t in time} >=0;
var LGw1{t in time} >=0 :=1514.16471565281;
var XGwF1{t in time} >=0 :=2;
var XUseP1{t in time} >=0;
var XUseNp1{t in time} >=0;
var LStSSw1{t in time} >=0;
var XSwF1{t in time} >=0 :=2;
var LRes1{t in time} >=0 :=0;
var XResF1{t in time} >=0 :=0;

var DPGwWwtpFix >=0 <=1;
var DPPrice >=0 <=1;
var DPWtpGwFix >=0 <=1;
var DPCS >=0 <=100 integer;
var DPCS1 >=0 <=100 integer;
var DQAsrAddl >=0;
var DQDmR >=0;
var DQGwPumpAddl >=0;
var DQIbtWAddl >=0;
var DQIbtWwAddl >=0;
var DQNpdistAddl >=0;
var DQSwPumpAddl >=0;
var DQWrfAddl >=0;
var DQWtpAddl >=0;
var DQWwtpAddl >=0;
var DVResAddl >=0;
var DPriceDummy binary;

var CLuSet1 >=0 :=0;
var CLuSet2 >=0 :=0;
var CLuSet3 >=0 :=0;
var CLuSet4 >=0 :=0;
var CLuSet5 >=0 :=0;
var CLuSet6 >=0 :=0;
var CCGwPump >=0;
var COmGwPump{t in time} >=0;
var CGwPump >=0;
var CCSwPump >=0;
var COmSwPump{t in time} >=0;
var CSwPump >=0;
var CCWtp >=0;
var COmWtp{t in time} >=0;
var CWtp >=0;
var CWtpUaw >=0;
var CCWwtp >=0;
var COmWwtp{t in time} >=0;
var CWwtp >=0;
var CGwWwtp >=0;
var CPPrice >=0;
var CDmd >=0;
var CCWrf >=0;
var COmWrf{t in time} >=0;
var CWrf >=0;
var CCNpdist >=0;
var COmNpdist{t in time} >=0;
var CNpdist >=0;
var CCAsr >=0;
var COmAsr{t in time} >=0;
var CAsr >=0;
var CCRes >=0;
var COmRes{t in time} >=0;
var CRes >=0;
var CCIbtW >=0;
var COmIbtW{t in time} >=0;
var CIbtW >=0;
var CCIbtWw >=0;
var COmIbtWw{t in time} >=0;
var CIbtWw >=0;
var CWMake >=0;
var CGwMake >=0;
var CWFlex >=0;
var CGwFlex >=0;
var CFlood{t in time} >=0 :=0;

var QWtpGw{t in time}
  = QUsePI1[t] - (QUsePI1[t] * DPWtpGwFix);
var QUseP2{t in time}
  = (1-(PUseNp2[t] / 100)) * QUsePI2[t] + (1-(PUseNp2[t] / 100)) * QUsePI2[t] * 0 * DPPrice - (1-(PUseNp2[t] / 100)) * FPUse2[t] * DQDmR;
var QUseNp2{t in time}
  = (PUseNp2[t] / 100) * QUsePI2[t] + (PUseNp2[t] / 100) * QUsePI2[t] * 0 * DPPrice - (PUseNp2[t] / 100) * FNpUse2[t] * DQDmR;
var QGwWwtp{t in time}
   = (0 * QUsePI2[t] * (1 - PConsUsePI2[t] / 100) * 1) / 1 - (0 * QUsePI2[t] * (1 - PConsUsePI2[t] / 100) * 1 * DPGwWwtpFix) / 1;
var QUsePSep{t in time}
  = QUseP2[t] * (1 - PConsUseP2[t] / 100) * 0;
var QUsePSepExt{t in time}
  = QUseP2[t] * (1 - PConsUseP2[t] / 100) * 0;
var QUseNpSep{t in time}
  = QUseNp2[t] * (1 - PConsUseNp2[t] / 100) * 0;
var QUseNpSepExt{t in time}
  = QUseNp2[t] * (1 - PConsUseNp2[t] / 100) * 0;

var LWtpUseP1{t in time} >=0;
var LWtpUseNp1{t in time} >=0;
var LWtpGw1{t in time} >=0;
var LWwtpSw1{t in time} >=0;
var LWwtpWrf1{t in time} >=0;
var LWrfUseNp1{t in time} >=0;
var LWrfAsr1{t in time} >=0;
var LWrfSw1{t in time} >=0;
var LAsrGw1{t in time} >=0;
var LSepGw1{t in time} >=0;
var LGwSw1{t in time} >=0;
var LGwWtp1{t in time} >=0;
var LGwWwtp1{t in time} >=0;
var LGwExt1{t in time} >=0;
var LGwPt1{t in time} >=0;
var LUseP1{t in time} >=0;
var LUsePSanS1{t in time} >=0;
var LUsePSep1{t in time} >=0;
var LUsePSepExt1{t in time} >=0;
var LUsePIbtWw1{t in time} >=0;
var LUseNp1{t in time} >=0;
var LUseNpSanS1{t in time} >=0;
var LUseNpSep1{t in time} >=0;
var LUseNpSepExt1{t in time} >=0;
var LUseNpIbtWw1{t in time} >=0;
var LSw1{t in time} >=0;
var LSwRes1{t in time} >=0;
var LSwAsr1{t in time} >=0;
var LSwWtp1{t in time} >=0;
var LSwPt1{t in time} >=0;
var LResPt1{t in time} >=0;
var LResWtp1{t in time} >=0;
var LResAsr1{t in time} >=0;
var LSwExt1{t in time} >=0;

minimize cost: CLuSet1 + CLuSet2 + CLuSet3 + CLuSet4 + CLuSet5 + CLuSet6 + CGwPump + CSwPump + CWtp + CWtpUaw + CWwtp + CGwWwtp + CPPrice + CDmd + CWrf + CNpdist + CAsr + CRes + CIbtW + CIbtWw + CWMake + CGwMake +CWFlex + CGwFlex + sum{t in time}CFlood[t];

subject to runoff{t in time}:
  QRu[t] = QRuU11[t] * DALu11 + QRuU21[t] * DALu21 + QRuU31[t] * DALu31 + QRuU41[t] * DALu41 + QRuU51[t] * DALu51 + QRuU61[t] * DALu61 + QRuU71[t] * DALu71 + QRuU81[t] * DALu81 + QRuU91[t] * DALu91 + QRuU101[t] * DALu101 + (QRuU12[t] - QRuU11[t]) * DALu12 + (QRuU22[t] - QRuU21[t]) * DALu22 + (QRuU32[t] - QRuU31[t]) * DALu32 + (QRuU42[t] - QRuU41[t]) * DALu42 + (QRuU52[t] - QRuU51[t]) * DALu52 + (QRuU62[t] - QRuU61[t]) * DALu62 + (QRuU72[t] - QRuU71[t]) * DALu72 + (QRuU82[t] - QRuU81[t]) * DALu82 + (QRuU92[t] - QRuU91[t]) * DALu92 + (QRuU102[t] - QRuU101[t]) * DALu102 + (QRuU13[t] - QRuU11[t]) * DALu13 + (QRuU23[t] - QRuU21[t]) * DALu23 + (QRuU33[t] - QRuU31[t]) * DALu33 + (QRuU43[t] - QRuU41[t]) * DALu43 + (QRuU53[t] - QRuU51[t]) * DALu53 + (QRuU63[t] - QRuU61[t]) * DALu63 + (QRuU73[t] - QRuU71[t]) * DALu73 + (QRuU83[t] - QRuU81[t]) * DALu83 + (QRuU93[t] - QRuU91[t]) * DALu93 + (QRuU103[t] - QRuU101[t]) * DALu103 + (QRuU14[t] - QRuU11[t]) * DALu14 + (QRuU24[t] - QRuU21[t]) * DALu24 + (QRuU34[t] - QRuU31[t]) * DALu34 + (QRuU44[t] - QRuU41[t]) * DALu44 + (QRuU54[t] - QRuU51[t]) * DALu54 + (QRuU64[t] - QRuU61[t]) * DALu64 + (QRuU74[t] - QRuU71[t]) * DALu74 + (QRuU84[t] - QRuU81[t]) * DALu84 + (QRuU94[t] - QRuU91[t]) * DALu94 + (QRuU104[t] - QRuU101[t]) * DALu104 + (QRuU15[t] - QRuU11[t]) * DALu15 + (QRuU25[t] - QRuU21[t]) * DALu25 + (QRuU35[t] - QRuU31[t]) * DALu35 + (QRuU45[t] - QRuU41[t]) * DALu45 + (QRuU55[t] - QRuU51[t]) * DALu55 + (QRuU65[t] - QRuU61[t]) * DALu65 + (QRuU75[t] - QRuU71[t]) * DALu75 + (QRuU85[t] - QRuU81[t]) * DALu85 + (QRuU95[t] - QRuU91[t]) * DALu95 + (QRuU105[t] - QRuU101[t]) * DALu105 + (QRuU16[t] - QRuU11[t]) * DALu16 + (QRuU26[t] - QRuU21[t]) * DALu26 + (QRuU36[t] - QRuU31[t]) * DALu36 + (QRuU46[t] - QRuU41[t]) * DALu46 + (QRuU56[t] - QRuU51[t]) * DALu56 + (QRuU66[t] - QRuU61[t]) * DALu66 + (QRuU76[t] - QRuU71[t]) * DALu76 + (QRuU86[t] - QRuU81[t]) * DALu86 + (QRuU96[t] - QRuU91[t]) * DALu96 + (QRuU106[t] - QRuU101[t]) * DALu106;

subject to recharge{t in time}:
  QRe[t] = QReU11[t] * DALu11 + QReU21[t] * DALu21 + QReU31[t] * DALu31 + QReU41[t] * DALu41 + QReU51[t] * DALu51 + QReU61[t] * DALu61 + QReU71[t] * DALu71 + QReU81[t] * DALu81 + QReU91[t] * DALu91 + QReU101[t] * DALu101 + (QReU12[t] - QReU11[t]) * DALu12 + (QReU22[t] - QReU21[t]) * DALu22 + (QReU32[t] - QReU31[t]) * DALu32 + (QReU42[t] - QReU41[t]) * DALu42 + (QReU52[t] - QReU51[t]) * DALu52 + (QReU62[t] - QReU61[t]) * DALu62 + (QReU72[t] - QReU71[t]) * DALu72 + (QReU82[t] - QReU81[t]) * DALu82 + (QReU92[t] - QReU91[t]) * DALu92 + (QReU102[t] - QReU101[t]) * DALu102 + (QReU13[t] - QReU11[t]) * DALu13 + (QReU23[t] - QReU21[t]) * DALu23 + (QReU33[t] - QReU31[t]) * DALu33 + (QReU43[t] - QReU41[t]) * DALu43 + (QReU53[t] - QReU51[t]) * DALu53 + (QReU63[t] - QReU61[t]) * DALu63 + (QReU73[t] - QReU71[t]) * DALu73 + (QReU83[t] - QReU81[t]) * DALu83 + (QReU93[t] - QReU91[t]) * DALu93 + (QReU103[t] - QReU101[t]) * DALu103 + (QReU14[t] - QReU11[t]) * DALu14 + (QReU24[t] - QReU21[t]) * DALu24 + (QReU34[t] - QReU31[t]) * DALu34 + (QReU44[t] - QReU41[t]) * DALu44 + (QReU54[t] - QReU51[t]) * DALu54 + (QReU64[t] - QReU61[t]) * DALu64 + (QReU74[t] - QReU71[t]) * DALu74 + (QReU84[t] - QReU81[t]) * DALu84 + (QReU94[t] - QReU91[t]) * DALu94 + (QReU104[t] - QReU101[t]) * DALu104 + (QReU15[t] - QReU11[t]) * DALu15 + (QReU25[t] - QReU21[t]) * DALu25 + (QReU35[t] - QReU31[t]) * DALu35 + (QReU45[t] - QReU41[t]) * DALu45 + (QReU55[t] - QReU51[t]) * DALu55 + (QReU65[t] - QReU61[t]) * DALu65 + (QReU75[t] - QReU71[t]) * DALu75 + (QReU85[t] - QReU81[t]) * DALu85 + (QReU95[t] - QReU91[t]) * DALu95 + (QReU105[t] - QReU101[t]) * DALu105 + (QReU16[t] - QReU11[t]) * DALu16 + (QReU26[t] - QReU21[t]) * DALu26 + (QReU36[t] - QReU31[t]) * DALu36 + (QReU46[t] - QReU41[t]) * DALu46 + (QReU56[t] - QReU51[t]) * DALu56 + (QReU66[t] - QReU61[t]) * DALu66 + (QReU76[t] - QReU71[t]) * DALu76 + (QReU86[t] - QReU81[t]) * DALu86 + (QReU96[t] - QReU91[t]) * DALu96 + (QReU106[t] - QReU101[t]) * DALu106;

subject to septic_groundwater{t in time}:
  QSepGw[t] = QUsePSep[t] + QUseNpSep[t];

subject to wtp{t in time}:
  DQResWtp[t] + DQSwWtp[t] + DQGwWtp[t] = QWtpUseP[t] + DQWtpUseNp[t] + QWtpGw[t];

subject to wrf{t in time}:
  DQWwtpWrf[t] = QWrfSw[t] + DQWrfUseNp[t] + DQWrfAsr[t];

subject to asr_gw{t in time}:
  DQSwAsr[t] + DQResAsr[t] + DQWrfAsr[t] = QAsrGw[t];

subject to gw_extmin1:
  DQGwExt[1] = 0;
subject to gw_extmin2:
  DQGwExt[2] = 0;
subject to gw_extmin3:
  DQGwExt[3] = 0;
subject to gw_extmin4:
  DQGwExt[4] = 0;
subject to gw_extmin5:
  DQGwExt[5] = 0;
subject to gw_extmin6:
  DQGwExt[6] = 0;
subject to gw_extmin7:
  DQGwExt[7] = 0;
subject to gw_extmin8:
  DQGwExt[8] = 0;
subject to gw_extmin9:
  DQGwExt[9] = 0;
subject to gw_extmin10:
  DQGwExt[10] = 0;
subject to gw_extmin11:
  DQGwExt[11] = 0;
subject to gw_extmin12:
  DQGwExt[12] = 0;
subject to gw_extmin13:
  DQGwExt[13] = 0;
subject to gw_extmin14:
  DQGwExt[14] = 0;
subject to gw_extmin15:
  DQGwExt[15] = 0;
subject to gw_extmin16:
  DQGwExt[16] = 0;
subject to gw_extmin17:
  DQGwExt[17] = 0;
subject to gw_extmin18:
  DQGwExt[18] = 0;
subject to gw_extmin19:
  DQGwExt[19] = 0;
subject to gw_extmin20:
  DQGwExt[20] = 0;
subject to gw_extmin21:
  DQGwExt[21] = 0;
subject to gw_extmin22:
  DQGwExt[22] = 0;
subject to gw_extmin23:
  DQGwExt[23] = 0;
subject to gw_extmin24:
  DQGwExt[24] = 0;
subject to gw_extmin25:
  DQGwExt[25] = 0;
subject to gw_extmin26:
  DQGwExt[26] = 0;
subject to gw_extmin27:
  DQGwExt[27] = 0;
subject to gw_extmin28:
  DQGwExt[28] = 0;
subject to gw_extmin29:
  DQGwExt[29] = 0;
subject to gw_extmin30:
  DQGwExt[30] = 0;
subject to gw_extmin31:
  DQGwExt[31] = 0;
subject to gw_extmin32:
  DQGwExt[32] = 0;
subject to gw_extmin33:
  DQGwExt[33] = 0;
subject to gw_extmin34:
  DQGwExt[34] = 0;
subject to gw_extmin35:
  DQGwExt[35] = 0;
subject to gw_extmin36:
  DQGwExt[36] = 0;
subject to gw_extmin37:
  DQGwExt[37] = 0;
subject to gw_extmin38:
  DQGwExt[38] = 0;
subject to gw_extmin39:
  DQGwExt[39] = 0;
subject to gw_extmin40:
  DQGwExt[40] = 0;
subject to gw_extmin41:
  DQGwExt[41] = 0;
subject to gw_extmin42:
  DQGwExt[42] = 0;
subject to gw_extmin43:
  DQGwExt[43] = 0;
subject to gw_extmin44:
  DQGwExt[44] = 0;
subject to gw_extmin45:
  DQGwExt[45] = 0;
subject to gw_extmin46:
  DQGwExt[46] = 0;
subject to gw_extmin47:
  DQGwExt[47] = 0;
subject to gw_extmin48:
  DQGwExt[48] = 0;
subject to gw_extmin49:
  DQGwExt[49] = 0;
subject to gw_extmin50:
  DQGwExt[50] = 0;
subject to gw_extmin51:
  DQGwExt[51] = 0;
subject to gw_extmin52:
  DQGwExt[52] = 0;
subject to gw_extmin53:
  DQGwExt[53] = 0;
subject to gw_extmin54:
  DQGwExt[54] = 0;
subject to gw_extmin55:
  DQGwExt[55] = 0;
subject to gw_extmin56:
  DQGwExt[56] = 0;
subject to gw_extmin57:
  DQGwExt[57] = 0;
subject to gw_extmin58:
  DQGwExt[58] = 0;
subject to gw_extmin59:
  DQGwExt[59] = 0;
subject to gw_extmin60:
  DQGwExt[60] = 0;
subject to gw_extmin61:
  DQGwExt[61] = 0;
subject to gw_extmin62:
  DQGwExt[62] = 0;
subject to gw_extmin63:
  DQGwExt[63] = 0;
subject to gw_extmin64:
  DQGwExt[64] = 0;
subject to gw_extmin65:
  DQGwExt[65] = 0;
subject to gw_extmin66:
  DQGwExt[66] = 0;
subject to gw_extmin67:
  DQGwExt[67] = 0;
subject to gw_extmin68:
  DQGwExt[68] = 0;
subject to gw_extmin69:
  DQGwExt[69] = 0;
subject to gw_extmin70:
  DQGwExt[70] = 0;
subject to gw_extmin71:
  DQGwExt[71] = 0;
subject to gw_extmin72:
  DQGwExt[72] = 0;
subject to gw_extmin73:
  DQGwExt[73] = 0;
subject to gw_extmin74:
  DQGwExt[74] = 0;
subject to gw_extmin75:
  DQGwExt[75] = 0;
subject to gw_extmin76:
  DQGwExt[76] = 0;
subject to gw_extmin77:
  DQGwExt[77] = 0;
subject to gw_extmin78:
  DQGwExt[78] = 0;
subject to gw_extmin79:
  DQGwExt[79] = 0;
subject to gw_extmin80:
  DQGwExt[80] = 0;
subject to gw_extmin81:
  DQGwExt[81] = 0;
subject to gw_extmin82:
  DQGwExt[82] = 0;
subject to gw_extmin83:
  DQGwExt[83] = 0;
subject to gw_extmin84:
  DQGwExt[84] = 0;
subject to gw_extmin85:
  DQGwExt[85] = 0;
subject to gw_extmin86:
  DQGwExt[86] = 0;
subject to gw_extmin87:
  DQGwExt[87] = 0;
subject to gw_extmin88:
  DQGwExt[88] = 0;
subject to gw_extmin89:
  DQGwExt[89] = 0;
subject to gw_extmin90:
  DQGwExt[90] = 0;
subject to gw_extmin91:
  DQGwExt[91] = 0;
subject to gw_extmin92:
  DQGwExt[92] = 0;
subject to gw_extmin93:
  DQGwExt[93] = 0;
subject to gw_extmin94:
  DQGwExt[94] = 0;
subject to gw_extmin95:
  DQGwExt[95] = 0;
subject to gw_extmin96:
  DQGwExt[96] = 0;
subject to gw_extmin97:
  DQGwExt[97] = 0;
subject to gw_extmin98:
  DQGwExt[98] = 0;
subject to gw_extmin99:
  DQGwExt[99] = 0;
subject to gw_extmin100:
  DQGwExt[100] = 0;
subject to gw_extmin101:
  DQGwExt[101] = 0;
subject to gw_extmin102:
  DQGwExt[102] = 0;
subject to gw_extmin103:
  DQGwExt[103] = 0;
subject to gw_extmin104:
  DQGwExt[104] = 0;
subject to gw_extmin105:
  DQGwExt[105] = 0;
subject to gw_extmin106:
  DQGwExt[106] = 0;
subject to gw_extmin107:
  DQGwExt[107] = 0;
subject to gw_extmin108:
  DQGwExt[108] = 0;
subject to gw_extmin109:
  DQGwExt[109] = 0;
subject to gw_extmin110:
  DQGwExt[110] = 0;
subject to gw_extmin111:
  DQGwExt[111] = 0;
subject to gw_extmin112:
  DQGwExt[112] = 0;
subject to gw_extmin113:
  DQGwExt[113] = 0;
subject to gw_extmin114:
  DQGwExt[114] = 0;
subject to gw_extmin115:
  DQGwExt[115] = 0;
subject to gw_extmin116:
  DQGwExt[116] = 0;
subject to gw_extmin117:
  DQGwExt[117] = 0;
subject to gw_extmin118:
  DQGwExt[118] = 0;
subject to gw_extmin119:
  DQGwExt[119] = 0;
subject to gw_extmin120:
  DQGwExt[120] = 0;
subject to gw_extmin121:
  DQGwExt[121] = 0;
subject to gw_extmin122:
  DQGwExt[122] = 0;
subject to gw_extmin123:
  DQGwExt[123] = 0;
subject to gw_extmin124:
  DQGwExt[124] = 0;
subject to gw_extmin125:
  DQGwExt[125] = 0;
subject to gw_extmin126:
  DQGwExt[126] = 0;
subject to gw_extmin127:
  DQGwExt[127] = 0;
subject to gw_extmin128:
  DQGwExt[128] = 0;
subject to gw_extmin129:
  DQGwExt[129] = 0;
subject to gw_extmin130:
  DQGwExt[130] = 0;
subject to gw_extmin131:
  DQGwExt[131] = 0;
subject to gw_extmin132:
  DQGwExt[132] = 0;
subject to gw_extmin133:
  DQGwExt[133] = 0;
subject to gw_extmin134:
  DQGwExt[134] = 0;
subject to gw_extmin135:
  DQGwExt[135] = 0;
subject to gw_extmin136:
  DQGwExt[136] = 0;
subject to gw_extmin137:
  DQGwExt[137] = 0;
subject to gw_extmin138:
  DQGwExt[138] = 0;
subject to gw_extmin139:
  DQGwExt[139] = 0;
subject to gw_extmin140:
  DQGwExt[140] = 0;
subject to gw_extmin141:
  DQGwExt[141] = 0;
subject to gw_extmin142:
  DQGwExt[142] = 0;
subject to gw_extmin143:
  DQGwExt[143] = 0;
subject to gw_extmin144:
  DQGwExt[144] = 0;
subject to gw_extmin145:
  DQGwExt[145] = 0;
subject to gw_extmin146:
  DQGwExt[146] = 0;
subject to gw_extmin147:
  DQGwExt[147] = 0;
subject to gw_extmin148:
  DQGwExt[148] = 0;
subject to gw_extmin149:
  DQGwExt[149] = 0;
subject to gw_extmin150:
  DQGwExt[150] = 0;
subject to gw_extmin151:
  DQGwExt[151] = 0;
subject to gw_extmin152:
  DQGwExt[152] = 0;
subject to gw_extmin153:
  DQGwExt[153] = 0;
subject to gw_extmin154:
  DQGwExt[154] = 0;
subject to gw_extmin155:
  DQGwExt[155] = 0;
subject to gw_extmin156:
  DQGwExt[156] = 0;
subject to gw_extmin157:
  DQGwExt[157] = 0;
subject to gw_extmin158:
  DQGwExt[158] = 0;
subject to gw_extmin159:
  DQGwExt[159] = 0;
subject to gw_extmin160:
  DQGwExt[160] = 0;
subject to gw_extmin161:
  DQGwExt[161] = 0;
subject to gw_extmin162:
  DQGwExt[162] = 0;
subject to gw_extmin163:
  DQGwExt[163] = 0;
subject to gw_extmin164:
  DQGwExt[164] = 0;
subject to gw_extmin165:
  DQGwExt[165] = 0;
subject to gw_extmin166:
  DQGwExt[166] = 0;
subject to gw_extmin167:
  DQGwExt[167] = 0;
subject to gw_extmin168:
  DQGwExt[168] = 0;
subject to gw_extmin169:
  DQGwExt[169] = 0;
subject to gw_extmin170:
  DQGwExt[170] = 0;
subject to gw_extmin171:
  DQGwExt[171] = 0;
subject to gw_extmin172:
  DQGwExt[172] = 0;
subject to gw_extmin173:
  DQGwExt[173] = 0;
subject to gw_extmin174:
  DQGwExt[174] = 0;
subject to gw_extmin175:
  DQGwExt[175] = 0;
subject to gw_extmin176:
  DQGwExt[176] = 0;
subject to gw_extmin177:
  DQGwExt[177] = 0;
subject to gw_extmin178:
  DQGwExt[178] = 0;
subject to gw_extmin179:
  DQGwExt[179] = 0;
subject to gw_extmin180:
  DQGwExt[180] = 0;
subject to gw_extmin181:
  DQGwExt[181] = 0;
subject to gw_extmin182:
  DQGwExt[182] = 0;
subject to gw_extmin183:
  DQGwExt[183] = 0;
subject to gw_extmin184:
  DQGwExt[184] = 0;
subject to gw_extmin185:
  DQGwExt[185] = 0;
subject to gw_extmin186:
  DQGwExt[186] = 0;
subject to gw_extmin187:
  DQGwExt[187] = 0;
subject to gw_extmin188:
  DQGwExt[188] = 0;
subject to gw_extmin189:
  DQGwExt[189] = 0;
subject to gw_extmin190:
  DQGwExt[190] = 0;
subject to gw_extmin191:
  DQGwExt[191] = 0;
subject to gw_extmin192:
  DQGwExt[192] = 0;
subject to gw_extmin193:
  DQGwExt[193] = 0;
subject to gw_extmin194:
  DQGwExt[194] = 0;
subject to gw_extmin195:
  DQGwExt[195] = 0;
subject to gw_extmin196:
  DQGwExt[196] = 0;
subject to gw_extmin197:
  DQGwExt[197] = 0;
subject to gw_extmin198:
  DQGwExt[198] = 0;
subject to gw_extmin199:
  DQGwExt[199] = 0;
subject to gw_extmin200:
  DQGwExt[200] = 0;
subject to gw_extmin201:
  DQGwExt[201] = 0;
subject to gw_extmin202:
  DQGwExt[202] = 0;
subject to gw_extmin203:
  DQGwExt[203] = 0;
subject to gw_extmin204:
  DQGwExt[204] = 0;
subject to gw_extmin205:
  DQGwExt[205] = 0;
subject to gw_extmin206:
  DQGwExt[206] = 0;
subject to gw_extmin207:
  DQGwExt[207] = 0;
subject to gw_extmin208:
  DQGwExt[208] = 0;
subject to gw_extmin209:
  DQGwExt[209] = 0;
subject to gw_extmin210:
  DQGwExt[210] = 0;
subject to gw_extmin211:
  DQGwExt[211] = 0;
subject to gw_extmin212:
  DQGwExt[212] = 0;
subject to gw_extmin213:
  DQGwExt[213] = 0;
subject to gw_extmin214:
  DQGwExt[214] = 0;
subject to gw_extmin215:
  DQGwExt[215] = 0;
subject to gw_extmin216:
  DQGwExt[216] = 0;
subject to gw_extmin217:
  DQGwExt[217] = 0;
subject to gw_extmin218:
  DQGwExt[218] = 0;
subject to gw_extmin219:
  DQGwExt[219] = 0;
subject to gw_extmin220:
  DQGwExt[220] = 0;
subject to gw_extmin221:
  DQGwExt[221] = 0;
subject to gw_extmin222:
  DQGwExt[222] = 0;
subject to gw_extmin223:
  DQGwExt[223] = 0;
subject to gw_extmin224:
  DQGwExt[224] = 0;
subject to gw_extmin225:
  DQGwExt[225] = 0;
subject to gw_extmin226:
  DQGwExt[226] = 0;
subject to gw_extmin227:
  DQGwExt[227] = 0;
subject to gw_extmin228:
  DQGwExt[228] = 0;
subject to gw_extmin229:
  DQGwExt[229] = 0;
subject to gw_extmin230:
  DQGwExt[230] = 0;
subject to gw_extmin231:
  DQGwExt[231] = 0;
subject to gw_extmin232:
  DQGwExt[232] = 0;
subject to gw_extmin233:
  DQGwExt[233] = 0;
subject to gw_extmin234:
  DQGwExt[234] = 0;
subject to gw_extmin235:
  DQGwExt[235] = 0;
subject to gw_extmin236:
  DQGwExt[236] = 0;
subject to gw_extmin237:
  DQGwExt[237] = 0;
subject to gw_extmin238:
  DQGwExt[238] = 0;
subject to gw_extmin239:
  DQGwExt[239] = 0;
subject to gw_extmin240:
  DQGwExt[240] = 0;
subject to gw_extmin241:
  DQGwExt[241] = 0;
subject to gw_extmin242:
  DQGwExt[242] = 0;
subject to gw_extmin243:
  DQGwExt[243] = 0;
subject to gw_extmin244:
  DQGwExt[244] = 0;
subject to gw_extmin245:
  DQGwExt[245] = 0;
subject to gw_extmin246:
  DQGwExt[246] = 0;
subject to gw_extmin247:
  DQGwExt[247] = 0;
subject to gw_extmin248:
  DQGwExt[248] = 0;
subject to gw_extmin249:
  DQGwExt[249] = 0;
subject to gw_extmin250:
  DQGwExt[250] = 0;
subject to gw_extmin251:
  DQGwExt[251] = 0;
subject to gw_extmin252:
  DQGwExt[252] = 0;
subject to gw_extmin253:
  DQGwExt[253] = 0;
subject to gw_extmin254:
  DQGwExt[254] = 0;
subject to gw_extmin255:
  DQGwExt[255] = 0;
subject to gw_extmin256:
  DQGwExt[256] = 0;
subject to gw_extmin257:
  DQGwExt[257] = 0;
subject to gw_extmin258:
  DQGwExt[258] = 0;
subject to gw_extmin259:
  DQGwExt[259] = 0;
subject to gw_extmin260:
  DQGwExt[260] = 0;
subject to gw_extmin261:
  DQGwExt[261] = 0;
subject to gw_extmin262:
  DQGwExt[262] = 0;
subject to gw_extmin263:
  DQGwExt[263] = 0;
subject to gw_extmin264:
  DQGwExt[264] = 0;
subject to gw_extmin265:
  DQGwExt[265] = 0;
subject to gw_extmin266:
  DQGwExt[266] = 0;
subject to gw_extmin267:
  DQGwExt[267] = 0;
subject to gw_extmin268:
  DQGwExt[268] = 0;
subject to gw_extmin269:
  DQGwExt[269] = 0;
subject to gw_extmin270:
  DQGwExt[270] = 0;
subject to gw_extmin271:
  DQGwExt[271] = 0;
subject to gw_extmin272:
  DQGwExt[272] = 0;
subject to gw_extmin273:
  DQGwExt[273] = 0;
subject to gw_extmin274:
  DQGwExt[274] = 0;
subject to gw_extmin275:
  DQGwExt[275] = 0;
subject to gw_extmin276:
  DQGwExt[276] = 0;
subject to gw_extmin277:
  DQGwExt[277] = 0;
subject to gw_extmin278:
  DQGwExt[278] = 0;
subject to gw_extmin279:
  DQGwExt[279] = 0;
subject to gw_extmin280:
  DQGwExt[280] = 0;
subject to gw_extmin281:
  DQGwExt[281] = 0;
subject to gw_extmin282:
  DQGwExt[282] = 0;
subject to gw_extmin283:
  DQGwExt[283] = 0;
subject to gw_extmin284:
  DQGwExt[284] = 0;
subject to gw_extmin285:
  DQGwExt[285] = 0;
subject to gw_extmin286:
  DQGwExt[286] = 0;
subject to gw_extmin287:
  DQGwExt[287] = 0;
subject to gw_extmin288:
  DQGwExt[288] = 0;
subject to gw_extmin289:
  DQGwExt[289] = 0;
subject to gw_extmin290:
  DQGwExt[290] = 0;
subject to gw_extmin291:
  DQGwExt[291] = 0;
subject to gw_extmin292:
  DQGwExt[292] = 0;
subject to gw_extmin293:
  DQGwExt[293] = 0;
subject to gw_extmin294:
  DQGwExt[294] = 0;
subject to gw_extmin295:
  DQGwExt[295] = 0;
subject to gw_extmin296:
  DQGwExt[296] = 0;
subject to gw_extmin297:
  DQGwExt[297] = 0;
subject to gw_extmin298:
  DQGwExt[298] = 0;
subject to gw_extmin299:
  DQGwExt[299] = 0;
subject to gw_extmin300:
  DQGwExt[300] = 0;
subject to gw_extmin301:
  DQGwExt[301] = 0;
subject to gw_extmin302:
  DQGwExt[302] = 0;
subject to gw_extmin303:
  DQGwExt[303] = 0;
subject to gw_extmin304:
  DQGwExt[304] = 0;
subject to gw_extmin305:
  DQGwExt[305] = 0;
subject to gw_extmin306:
  DQGwExt[306] = 0;
subject to gw_extmin307:
  DQGwExt[307] = 0;
subject to gw_extmin308:
  DQGwExt[308] = 0;
subject to gw_extmin309:
  DQGwExt[309] = 0;
subject to gw_extmin310:
  DQGwExt[310] = 0;
subject to gw_extmin311:
  DQGwExt[311] = 0;
subject to gw_extmin312:
  DQGwExt[312] = 0;
subject to gw_extmin313:
  DQGwExt[313] = 0;
subject to gw_extmin314:
  DQGwExt[314] = 0;
subject to gw_extmin315:
  DQGwExt[315] = 0;
subject to gw_extmin316:
  DQGwExt[316] = 0;
subject to gw_extmin317:
  DQGwExt[317] = 0;
subject to gw_extmin318:
  DQGwExt[318] = 0;
subject to gw_extmin319:
  DQGwExt[319] = 0;
subject to gw_extmin320:
  DQGwExt[320] = 0;
subject to gw_extmin321:
  DQGwExt[321] = 0;
subject to gw_extmin322:
  DQGwExt[322] = 0;
subject to gw_extmin323:
  DQGwExt[323] = 0;
subject to gw_extmin324:
  DQGwExt[324] = 0;
subject to gw_extmin325:
  DQGwExt[325] = 0;
subject to gw_extmin326:
  DQGwExt[326] = 0;
subject to gw_extmin327:
  DQGwExt[327] = 0;
subject to gw_extmin328:
  DQGwExt[328] = 0;
subject to gw_extmin329:
  DQGwExt[329] = 0;
subject to gw_extmin330:
  DQGwExt[330] = 0;
subject to gw_extmin331:
  DQGwExt[331] = 0;
subject to gw_extmin332:
  DQGwExt[332] = 0;
subject to gw_extmin333:
  DQGwExt[333] = 0;
subject to gw_extmin334:
  DQGwExt[334] = 0;
subject to gw_extmin335:
  DQGwExt[335] = 0;
subject to gw_extmin336:
  DQGwExt[336] = 0;
subject to gw_extmin337:
  DQGwExt[337] = 0;
subject to gw_extmin338:
  DQGwExt[338] = 0;
subject to gw_extmin339:
  DQGwExt[339] = 0;
subject to gw_extmin340:
  DQGwExt[340] = 0;
subject to gw_extmin341:
  DQGwExt[341] = 0;
subject to gw_extmin342:
  DQGwExt[342] = 0;
subject to gw_extmin343:
  DQGwExt[343] = 0;
subject to gw_extmin344:
  DQGwExt[344] = 0;
subject to gw_extmin345:
  DQGwExt[345] = 0;
subject to gw_extmin346:
  DQGwExt[346] = 0;
subject to gw_extmin347:
  DQGwExt[347] = 0;
subject to gw_extmin348:
  DQGwExt[348] = 0;
subject to gw_extmin349:
  DQGwExt[349] = 0;
subject to gw_extmin350:
  DQGwExt[350] = 0;
subject to gw_extmin351:
  DQGwExt[351] = 0;
subject to gw_extmin352:
  DQGwExt[352] = 0;
subject to gw_extmin353:
  DQGwExt[353] = 0;
subject to gw_extmin354:
  DQGwExt[354] = 0;
subject to gw_extmin355:
  DQGwExt[355] = 0;
subject to gw_extmin356:
  DQGwExt[356] = 0;
subject to gw_extmin357:
  DQGwExt[357] = 0;
subject to gw_extmin358:
  DQGwExt[358] = 0;
subject to gw_extmin359:
  DQGwExt[359] = 0;
subject to gw_extmin360:
  DQGwExt[360] = 0;
subject to gw_extmin361:
  DQGwExt[361] = 0;
subject to gw_extmin362:
  DQGwExt[362] = 0;
subject to gw_extmin363:
  DQGwExt[363] = 0;
subject to gw_extmin364:
  DQGwExt[364] = 0;
subject to gw_extmin365:
  DQGwExt[365] = 0;

subject to gw_sw_one{t in time}:
  QGwSw[first(time)] = 22.7124707347922;

subject to gw_sw{t in time: ord(t) > 1}:
  QGwSw[t] = 0.03 * VGw[t-1];

subject to vgw{t in time}:
  VGw[t] = (if t=first(time) then 757.082357826406 else VGw[t-1]) + QRe[t] + QExtGw[t] + QPtGw[t] + QWtpGw[t] + QAsrGw[t] + QSepGw[t] + DQGwMake[t] + DQGwFlex[t] - (QGwSw[t] + DQGwWtp[t] + QGwWwtp[t] + DQGwExt[t] + QGwPt[t]);

subject to usep{t in time}:
   DQUsePIbtWw[t] + DQUsePSanS[t] + QUsePSep[t] + QUsePSepExt[t] = (1 - PConsUseP2[t] / 100) * FPUse2[t] * QWtpUseP[t] + (1 - PConsUseP2[t] / 100) * FPUse2[t] * DQIbtWUseP[t];

subject to usep_min_constraint{t in time}:
   DQIbtWUseP[t] + QWtpUseP[t] >= QUseP2[t];

subject to usenp{t in time}:
   DQUseNpIbtWw[t] + DQUseNpSanS[t] + QUseNpSep[t] + QUseNpSepExt[t] = (1 - PConsUseNp2[t] / 100) * FNpUse2[t] * DQWtpUseNp[t] + (1 - PConsUseNp2[t] / 100) * FNpUse2[t] * DQWrfUseNp[t] + (1 - PConsUseNp2[t] / 100) * FNpUse2[t] * DQIbtWUseNp[t];

subject to usenp_min_constraint{t in time}:
   DQIbtWUseNp[t] + DQWtpUseNp[t] + DQWrfUseNp[t] >= QUseNp2[t];

subject to storm_sewer{t in time}:
  QRu[t] = QStSSw[t];

subject to sanitary_sewer{t in time}:
  DQUseNpSanS[t] + DQUsePSanS[t] + QGwWwtp[t] = QWwtpSw[t] + DQWwtpWrf[t];

subject to sw_balance{t in time}:
  QStSSw[t] + QExtSw[t] + QPtSw[t] + QGwSw[t] + QWwtpSw[t] + QWrfSw[t] = QSwRes[t] + DQSwWtp[t] + DQSwAsr[t] + QSwPt[t];


subject to vres{t in time}:
  VRes[t] = (if t=first(time) then 0 else VRes[t-1]) + QSwRes[t] + DQWMake[t] + DQWFlex[t] + QPtRes[t] - (DQSwExt[t] + DQResWtp[t] + DQResAsr[t] + QResPt[t]);

subject to vres_const{t in time: ord(t) > 1}:
  VRes[t] = VRes[t-1];

subject to sw_pump{t in time}:
   DQSwWtp[t] + DQResWtp[t] <= 0 + DQSwPumpAddl;

subject to gw_pump{t in time}:
   DQGwWtp[t] <= 0 + DQGwPumpAddl;

subject to wtp_max{t in time}:
   DQResWtp[t] + DQSwWtp[t] + DQGwWtp[t] <= 0 + DQWtpAddl;

subject to wwtp_max{t in time}:
   DQUseNpSanS[t] + QGwWwtp[t] + DQUsePSanS[t] <= 0 + DQWwtpAddl;

subject to wrf_max{t in time}:
   DQWwtpWrf[t] <= 0 + DQWrfAddl;

subject to asr_max{t in time}:
   DQSwAsr[t] + DQResAsr[t] + DQWrfAsr[t] <= 0 + DQAsrAddl;

subject to npdist_max{t in time}:
   DQWrfUseNp[t] <= 0 + DQNpdistAddl;

subject to vres_addl_max{t in time}:
   DVResAddl <= 0;

subject to vgw_min{t in time}:
   VGw[t] >= 37.8541178913203;

subject to vgw_max{t in time}:
   VGw[t] <= 18927.0589456602;

subject to lru1{t in time}:
  LRu1[t] = LRuU111[t] * DALu11 + LRuU211[t] * DALu21 + LRuU311[t] * DALu31 + LRuU411[t] * DALu41 + LRuU511[t] * DALu51 + LRuU611[t] * DALu61 + LRuU711[t] * DALu71 + LRuU811[t] * DALu81 + LRuU911[t] * DALu91 + LRuU1011[t] * DALu101 + (LRuU121[t] - LRuU111[t]) * DALu12 + (LRuU221[t] - LRuU211[t]) * DALu22 + (LRuU321[t] - LRuU311[t]) * DALu32 + (LRuU421[t] - LRuU411[t]) * DALu42 + (LRuU521[t] - LRuU511[t]) * DALu52 + (LRuU621[t] - LRuU611[t]) * DALu62 + (LRuU721[t] - LRuU711[t]) * DALu72 + (LRuU821[t] - LRuU811[t]) * DALu82 + (LRuU921[t] - LRuU911[t]) * DALu92 + (LRuU1021[t] - LRuU1011[t]) * DALu102 + (LRuU131[t] - LRuU111[t]) * DALu13 + (LRuU231[t] - LRuU211[t]) * DALu23 + (LRuU331[t] - LRuU311[t]) * DALu33 + (LRuU431[t] - LRuU411[t]) * DALu43 + (LRuU531[t] - LRuU511[t]) * DALu53 + (LRuU631[t] - LRuU611[t]) * DALu63 + (LRuU731[t] - LRuU711[t]) * DALu73 + (LRuU831[t] - LRuU811[t]) * DALu83 + (LRuU931[t] - LRuU911[t]) * DALu93 + (LRuU1031[t] - LRuU1011[t]) * DALu103 + (LRuU141[t] - LRuU111[t]) * DALu14 + (LRuU241[t] - LRuU211[t]) * DALu24 + (LRuU341[t] - LRuU311[t]) * DALu34 + (LRuU441[t] - LRuU411[t]) * DALu44 + (LRuU541[t] - LRuU511[t]) * DALu54 + (LRuU641[t] - LRuU611[t]) * DALu64 + (LRuU741[t] - LRuU711[t]) * DALu74 + (LRuU841[t] - LRuU811[t]) * DALu84 + (LRuU941[t] - LRuU911[t]) * DALu94 + (LRuU1041[t] - LRuU1011[t]) * DALu104 + (LRuU151[t] - LRuU111[t]) * DALu15 + (LRuU251[t] - LRuU211[t]) * DALu25 + (LRuU351[t] - LRuU311[t]) * DALu35 + (LRuU451[t] - LRuU411[t]) * DALu45 + (LRuU551[t] - LRuU511[t]) * DALu55 + (LRuU651[t] - LRuU611[t]) * DALu65 + (LRuU751[t] - LRuU711[t]) * DALu75 + (LRuU851[t] - LRuU811[t]) * DALu85 + (LRuU951[t] - LRuU911[t]) * DALu95 + (LRuU1051[t] - LRuU1011[t]) * DALu105 + (LRuU161[t] - LRuU111[t]) * DALu16 + (LRuU261[t] - LRuU211[t]) * DALu26 + (LRuU361[t] - LRuU311[t]) * DALu36 + (LRuU461[t] - LRuU411[t]) * DALu46 + (LRuU561[t] - LRuU511[t]) * DALu56 + (LRuU661[t] - LRuU611[t]) * DALu66 + (LRuU761[t] - LRuU711[t]) * DALu76 + (LRuU861[t] - LRuU811[t]) * DALu86 + (LRuU961[t] - LRuU911[t]) * DALu96 + (LRuU1061[t] - LRuU1011[t]) * DALu106;

subject to lre1{t in time}:
  LRe1[t] = LReU111[t] * DALu11 + LReU211[t] * DALu21 + LReU311[t] * DALu31 + LReU411[t] * DALu41 + LReU511[t] * DALu51 + LReU611[t] * DALu61 + LReU711[t] * DALu71 + LReU811[t] * DALu81 + LReU911[t] * DALu91 + LReU1011[t] * DALu101 + (LReU121[t] - LReU111[t])* DALu12 + (LReU221[t] - LReU211[t])* DALu22 + (LReU321[t] - LReU311[t])* DALu32 + (LReU421[t] - LReU411[t])* DALu42 + (LReU521[t] - LReU511[t])* DALu52 + (LReU621[t] - LReU611[t])* DALu62 + (LReU721[t] - LReU711[t])* DALu72 + (LReU821[t] - LReU811[t])* DALu82 + (LReU921[t] - LReU911[t])* DALu92 + (LReU1021[t] - LReU1011[t])* DALu102 + (LReU131[t] - LReU111[t])* DALu13 + (LReU231[t] - LReU211[t])* DALu23 + (LReU331[t] - LReU311[t])* DALu33 + (LReU431[t] - LReU411[t])* DALu43 + (LReU531[t] - LReU511[t])* DALu53 + (LReU631[t] - LReU611[t])* DALu63 + (LReU731[t] - LReU711[t])* DALu73 + (LReU831[t] - LReU811[t])* DALu83 + (LReU931[t] - LReU911[t])* DALu93 + (LReU1031[t] - LReU1011[t])* DALu103 + (LReU141[t] - LReU111[t])* DALu14 + (LReU241[t] - LReU211[t])* DALu24 + (LReU341[t] - LReU311[t])* DALu34 + (LReU441[t] - LReU411[t])* DALu44 + (LReU541[t] - LReU511[t])* DALu54 + (LReU641[t] - LReU611[t])* DALu64 + (LReU741[t] - LReU711[t])* DALu74 + (LReU841[t] - LReU811[t])* DALu84 + (LReU941[t] - LReU911[t])* DALu94 + (LReU1041[t] - LReU1011[t])* DALu104 + (LReU151[t] - LReU111[t])* DALu15 + (LReU251[t] - LReU211[t])* DALu25 + (LReU351[t] - LReU311[t])* DALu35 + (LReU451[t] - LReU411[t])* DALu45 + (LReU551[t] - LReU511[t])* DALu55 + (LReU651[t] - LReU611[t])* DALu65 + (LReU751[t] - LReU711[t])* DALu75 + (LReU851[t] - LReU811[t])* DALu85 + (LReU951[t] - LReU911[t])* DALu95 + (LReU1051[t] - LReU1011[t])* DALu105 + (LReU161[t] - LReU111[t])* DALu16 + (LReU261[t] - LReU211[t])* DALu26 + (LReU361[t] - LReU311[t])* DALu36 + (LReU461[t] - LReU411[t])* DALu46 + (LReU561[t] - LReU511[t])* DALu56 + (LReU661[t] - LReU611[t])* DALu66 + (LReU761[t] - LReU711[t])* DALu76 + (LReU861[t] - LReU811[t])* DALu86 + (LReU961[t] - LReU911[t])* DALu96 + (LReU1061[t] - LReU1011[t])* DALu106;

subject to lwtpusep1{t in time}:
  LWtpUseP1[t] = QWtpUseP[t] * 0;

subject to lwtpusenp1{t in time}:
  LWtpUseNp1[t] = DQWtpUseNp[t] * 0;

subject to lwtpgw1{t in time}:
  LWtpGw1[t] = QWtpGw[t] * 0;

subject to lwwtpsw1{t in time}:
  LWwtpSw1[t] = QWwtpSw[t] * 0;

subject to lwwtpwrf1{t in time}:
  LWwtpWrf1[t] = DQWwtpWrf[t] * 0;

subject to lwrfusenp1{t in time}:
  LWrfUseNp1[t] = DQWrfUseNp[t] * 0;

subject to lwrfasr1{t in time}:
  LWrfAsr1[t] = DQWrfAsr[t] * 0;

subject to lwrfsw1{t in time}:
  LWrfSw1[t] = QWrfSw[t] * 0;

subject to lasrgw1{t in time}:
  LAsrGw1[t] = QAsrGw[t] * 0;

subject to lsepgw1{t in time}:
  LSepGw1[t] = QSepGw[t] * 0;

subject to lgw1{t in time}:
  LGw1[t] = (if t=first(time) then 1514.16471565281 else LGw1[t-1]) + LRe1[t] + LExtGw1[t] + LPtGw1[t] + LWtpGw1[t] + LAsrGw1[t] + LSepGw1[t] - LGwSw1[t] - LGwWtp1[t] - LGwWwtp1[t] - LGwExt1[t] - LGwPt1[t];

subject to lgw_wtpI1:
  LGwWtp1[first(time)] = 2 * DQGwWtp[first(time)];

subject to lgw_wtp1{t in time: ord(t) > 1}:
  LGwWtp1[t] = XGwF1[t] * DQGwWtp[t];

subject to lgw_swI1:
  LGwSw1[first(time)] = 2 * QGwSw[first(time)];

subject to lgw_sw1{t in time: ord(t) > 1}:
  LGwSw1[t] = XGwF1[t] * QGwSw[t];

subject to lgw_wwtpI1:
  LGwWwtp1[first(time)] = 2 * QGwWwtp[first(time)];

subject to lgw_wwtp1{t in time: ord(t) > 1}:
  LGwWwtp1[t] = XGwF1[t] * QGwWwtp[t];

subject to lgw_extI1:
  LGwExt1[first(time)] = 2 * DQGwExt[first(time)];

subject to lgw_ext1{t in time: ord(t) > 1}:
  LGwExt1[t] = XGwF1[t] * DQGwExt[t];

subject to lgw_ptI1:
  LGwPt1[first(time)] = 2 * QGwPt[first(time)];

subject to lgw_pt1{t in time: ord(t) > 1}:
  LGwPt1[t] = XGwF1[t] * QGwPt[t];

subject to xgw1{t in time: ord(t) > 1}:
  XGwF1[t] = LGw1[t] / VGw[t];

subject to lusep1{t in time}:
  LUseP1[t] = ((1 - PConsUseP2[t] / 100) * FPUse2[t] * LWtpUseP1[t] + (1 - PConsUseP2[t] / 100) * FPUse2[t] * (DQIbtWUseP[t] * 0) + 0);

subject to xusep1{t in time}:
  XUseP1[t] * (QWtpUseP[t] + DQIbtWUseP[t]) = LUseP1[t];

subject to lusep_sans1{t in time}:
  LUsePSanS1[t] = XUseP1[t] * DQUsePSanS[t];

subject to lusep_sep1{t in time}:
  LUsePSep1[t] = XUseP1[t] * QUsePSep[t];

subject to lusep_sepext1{t in time}:
  LUsePSepExt1[t] = XUseP1[t] * QUsePSepExt[t];

subject to lusep_ibtww1{t in time}:
  LUsePIbtWw1[t] = XUseP1[t] * DQUsePIbtWw[t];

subject to lusenp1{t in time}:
  LUseNp1[t] = ((1 - PConsUseNp2[t] / 100) * FNpUse2[t] * LWtpUseNp1[t] + (1 - PConsUseNp2[t] / 100) * FNpUse2[t] * (DQIbtWUseNp[t] * 0) + (1 - PConsUseNp2[t]/ 100) * FNpUse2[t] * LWrfUseNp1[t] + 0);

subject to xusenp1{t in time}:
  XUseNp1[t] * (DQWtpUseNp[t] + DQWrfUseNp[t] + DQIbtWUseNp[t]) = LUseNp1[t];

subject to lusenp_sans1{t in time}:
  LUseNpSanS1[t] = XUseNp1[t] * DQUseNpSanS[t];

subject to lusenp_sep1{t in time}:
  LUseNpSep1[t] = XUseNp1[t] * QUseNpSep[t];

subject to lusenp_sepext1{t in time}:
  LUseNpSepExt1[t] = XUseNp1[t] * QUseNpSepExt[t];

subject to lusenp_ibtww1{t in time}:
  LUseNpIbtWw1[t] = XUseNp1[t] * DQUseNpIbtWw[t];

subject to lsts_sw1{t in time}:
  LStSSw1[t] = LRu1[t];

subject to lsw1{t in time}:
  LSw1[t] = LStSSw1[t] + LExtSw1[t] + LPtSw1[t] + LGwSw1[t] + LWwtpSw1[t] + LWrfSw1[t];

subject to xsw_final_I1:
  XSwF1[first(time)] <= 4;

subject to xsw_final1{t in time: ord(t) > 1}:
  XSwF1[t] * (QExtSw[t] + QPtSw[t] + QGwSw[t] + QWwtpSw[t] + QWrfSw[t] + QStSSw[t]) = LSw1[t];

subject to lsw_target1{t in time: ord(t) > 1}:
  LSw1[t] <= 7868.47619998004;

subject to lsw_target1_annual:
  sum{t in time}  LSw1[t] <= 63109.7422685089;

subject to lsw_res1{t in time}:
  LSwRes1[t] = XSwF1[t] * QSwRes[t];

subject to lsw_asr1{t in time}:
  LSwAsr1[t] = XSwF1[t] * DQSwAsr[t];

subject to lsw_wtp1{t in time}:
  LSwWtp1[t] = XSwF1[t] * DQSwWtp[t];

subject to lsw_pt1{t in time}:
  LSwPt1[t] = XSwF1[t] * QSwPt[t];

subject to lres1{t in time}:
  LRes1[t] = (if t=first(time) then 0 else LRes1[t-1]) + LSwRes1[t] + LPtRes1[t] - LSwExt1[t] - LResWtp1[t] - LResAsr1[t] - LResPt1[t];

subject to xres1{t in time: ord(t) > 1}:
  XResF1[t] = LRes1[t] / VRes[t];

subject to lres_ptI1:
  LResPt1[first(time)] = 0 * QResPt[first(time)];

subject to lres_pt1{t in time: ord(t) > 1}:
  LResPt1[t] = XResF1[t] * QResPt[t];

subject to lres_wtpI1:
  LResWtp1[first(time)] = 0 * DQResWtp[first(time)];

subject to lres_wtp1{t in time: ord(t) > 1}:
  LResWtp1[t] = XResF1[t] * DQResWtp[t];

subject to lres_asrI1:
  LResAsr1[first(time)] = 0 * DQResAsr[first(time)];

subject to lres_asr1{t in time: ord(t) > 1}:
  LResAsr1[t] = XResF1[t] * DQResAsr[t];

subject to lsw_extI1:
  LSwExt1[first(time)] = 0 * DQSwExt[first(time)];

subject to lsw_ext1{t in time: ord(t) > 1}:
  LSwExt1[t] = XResF1[t] * DQSwExt[t];

subject to c_luset1:
  CLuSet1 = 0;
subject to c_luset2:
  CLuSet2 = 54.0181562808425 * DALu12 + 11.7736164636535 * DALu12 + 54.0181562808425 * DALu22 + 11.7736164636535 * DALu22 + 122.347053122918 * DALu32 + 14.0461548008848 * DALu32 + 122.347053122918 * DALu42 + 14.0461548008848 * DALu42 + 67.5851670257089 * DALu52 + 26.0639453787701 * DALu52 + 67.5851670257089 * DALu62 + 26.0639453787701 * DALu62 + 83.3600744735154 * DALu72 + 8.64892263104654 * DALu72 + 83.3600744735154 * DALu82 + 8.64892263104654 * DALu82;
subject to c_luset3:
  CLuSet3 = 16.8006706442194 * DALu13 + 13.6622690399705 * DALu13 + 16.8006706442194 * DALu23 + 13.6622690399705 * DALu23 + 66.4787502894276 * DALu33 + 16.2993542773528 * DALu33 + 66.4787502894276 * DALu43 + 16.2993542773528 * DALu43 + 67.5851670257089 * DALu53 + 30.2449663709661 * DALu53 + 67.5851670257089 * DALu63 + 30.2449663709661 * DALu63 + 63.7361798227559 * DALu73 + 10.0363306598302 * DALu73 + 63.7361798227559 * DALu83 + 10.0363306598302 * DALu83;
subject to c_luset4:
  CLuSet4 = 94.3663428878643 * DALu14 + 11.2481445775008 * DALu14 + 94.3663428878643 * DALu24 + 11.2481445775008 * DALu24 + 94.3663428878643 * DALu34 + 13.4192565594482 * DALu34 + 94.3663428878643 * DALu44 + 13.4192565594482 * DALu44 + 94.3663428878643 * DALu54 + 24.9006774414253 * DALu54 + 94.3663428878643 * DALu64 + 24.9006774414253 * DALu64 + 94.3663428878643 * DALu74 + 8.26290991336076 * DALu74 + 94.3663428878643 * DALu84 + 8.26290991336076 * DALu84;
subject to c_luset5:
  CLuSet5 = 19.1527645344101 * DALu15 + 4.75209357912019 * DALu15 + 19.1527645344101 * DALu25 + 4.75209357912019 * DALu25 + 19.1527645344101 * DALu35 + 5.66934061820966 * DALu35 + 19.1527645344101 * DALu45 + 5.66934061820966 * DALu45 + 19.1527645344101 * DALu55 + 10.5199883029447 * DALu55 + 19.1527645344101 * DALu65 + 10.5199883029447 * DALu65 + 19.1527645344101 * DALu75 + 3.49089762081051 * DALu75 + 19.1527645344101 * DALu85 + 3.49089762081051 * DALu85;
subject to c_luset6:
  CLuSet6 = 139.205556766389 * DALu16 + 4.05146439758324 * DALu16 + 139.205556766389 * DALu26 + 4.05146439758324 * DALu26 + 663.624894768934 * DALu36 + 4.83347629629414 * DALu36 + 663.624894768934 * DALu46 + 4.83347629629414 * DALu46 + 605.356079435318 * DALu56 + 8.96896438648493 * DALu56 + 605.356079435318 * DALu66 + 8.96896438648493 * DALu66 + 605.356079435318 * DALu76 + 2.97621399722947 * DALu76 + 605.356079435318 * DALu86 + 2.97621399722947 * DALu86;

subject to cc_gwpump:
  CCGwPump = 0 + 0 * DQGwPumpAddl;
subject to com_gwpump{t in time}:
  COmGwPump[t] = 0 * DQGwWtp[t];
subject to c_gwpump:
  CGwPump = CCGwPump + sum{t in time}COmGwPump[t];

subject to cc_swpump:
  CCSwPump = 0 + 0 * DQSwPumpAddl;
subject to com_swpump{t in time}:
  COmSwPump[t] = 0 * DQSwWtp[t] + 0 * DQResWtp[t];
subject to c_swpump:
  CSwPump = CCSwPump + sum{t in time}COmSwPump[t];

subject to cc_wtp:
  CCWtp = 0 + 0 * DQWtpAddl;
subject to com_wtp{t in time}:
  COmWtp[t] = 0 * (DQResWtp[t] + DQSwWtp[t] + DQGwWtp[t]);
subject to c_wtp:
  CWtp = CCWtp + sum{t in time}COmWtp[t];

subject to c_wtp_uaw:
  CWtpUaw = 0 * DPWtpGwFix + 0 * DPWtpGwFix;

subject to cc_wwtp:
  CCWwtp = 0 + 0 * DQWwtpAddl;
subject to com_wwtp{t in time}:
  COmWwtp[t] = 0 * (DQUseNpSanS[t] + QGwWwtp[t] + DQUsePSanS[t]);
subject to c_wwtp:
  CWwtp = CCWwtp + sum{t in time}COmWwtp[t];

subject to c_gw_wwtp:
  CGwWwtp = 0 * DPGwWwtpFix + 0 * DPGwWwtpFix;

subject to c_pprice:
  CPPrice = 0;
subject to c_dmd:
  CDmd = 0;

subject to cc_wrf:
  CCWrf = 0 + 0 * DQWrfAddl;
subject to com_wrf{t in time}:
  COmWrf[t] = 0 * DQWwtpWrf[t];
subject to c_wrf:
  CWrf = CCWrf + sum{t in time}COmWrf[t];

subject to cc_npdist:
  CCNpdist = 0 + 0 * DQNpdistAddl;
subject to com_npdist{t in time}:
  COmNpdist[t] = 0 * DQWrfUseNp[t];
subject to c_npdist:
  CNpdist = CCNpdist + sum{t in time}COmNpdist[t];

subject to cc_asr:
  CCAsr = 0 + 0 * DQAsrAddl;
subject to com_asr{t in time}:
  COmAsr[t] = 0 * DQWrfAsr[t] + 0 * DQSwAsr[t] + 0 * DQResAsr[t];
subject to c_asr:
  CAsr = CCAsr + sum{t in time}COmAsr[t];

subject to cc_res:
  CCRes = 0 * DVResAddl;

subject to com_res{t in time}:
  COmRes[t] = 0 * DVResAddl + 0;

subject to c_res:
  CRes = CCRes + sum{t in time}COmRes[t];

subject to c_wmake:
  CWMake = sum{t in time}0.264172052358148 * DQWMake[t];
subject to c_gwmake:
  CGwMake = sum{t in time}264172.052358148 * DQGwMake[t];

subject to c_wflex:
  CWFlex = sum{t in time}1 * 0.01 * DQWFlex[t];
subject to c_gwflex:
  CGwFlex = sum{t in time}1 * 0.01 * DQGwFlex[t];
subject to com_ibtw{t in time}:
  COmIbtW[t] = 0;
subject to cc_ibtw:
  CCIbtW = 0;
subject to c_ibtw:
  CIbtW = 0;
subject to ibt_wusep{t in time}:
  DQIbtWUseP[t] = 0;
subject to ibt_wusenp{t in time}:
  DQIbtWUseNp[t] = 0;

subject to cc_ibtww:
  CCIbtWw = 0;
subject to com_ibtww{t in time}:
  COmIbtWw[t] = 0;
subject to c_ibtww:
  CIbtWw = 0;
subject to usep_ibtww{t in time}:
  DQUsePIbtWw[t] = 0;
subject to usenp_ibtww{t in time}:
  DQUseNpIbtWw[t] = 0;

subject to c_flood{t in time}:
  CFlood[t] = 0;

subject to sw_pump_addl:
  DQSwPumpAddl = 0;
subject to gw_pump_addl:
  DQGwPumpAddl = 0;
subject to wtp_addl:
  DQWtpAddl = 0;
subject to wwtp_addl:
  DQWwtpAddl = 0;
subject to wrf_addl:
  DQWrfAddl = 0;
subject to asr_addl:
  DQAsrAddl = 0;
subject to npdist_addl:
  DQNpdistAddl = 0;
subject to vres_addl:
  DVResAddl = 0;
subject to ibtw_addl:
  DQIbtWAddl = 0;
subject to ibtww_addl:
  DQIbtWwAddl = 0;
subject to exwmake{t in time}:
  DQWMake[t] = 0;
subject to modelgwflex{t in time}:
  DQGwFlex[t] = 0;
subject to modelwflex{t in time}:
  DQWFlex[t] = 0;
subject to pprice:
  DPPrice <= 0 * DPriceDummy;

subject to dmr:
  DQDmR = 0;

subject to pwtp_gw_fix:
  DPWtpGwFix <= 0;
subject to pgw_wwtp_fix:
  DPGwWwtpFix <= 0;

subject to a_lu_total:
  6646.28435782974 - 0.01 <= DALu11 + DALu21 + DALu31 + DALu41 + DALu51 + DALu61 + DALu71 + DALu81 + DALu91 + DALu101 <= 6646.28435782974 + 0.01;

subject to dalu11:
  DALu11 - 3671.87105109647 <= 0;
subject to dalu21:
  DALu21 - 592.695154233215 <= 0;
subject to dalu31:
  DALu31 - 624.968503164712 <= 0;
subject to dalu41:
  DALu41 - 150.502043436881 <= 0;
subject to dalu51:
  DALu51 - 179.983920503973 <= 0;
subject to dalu61:
  DALu61 - 52.5941112698915 <= 0;
subject to dalu71:
  DALu71 - 134.672109478118 <= 0;
subject to dalu81:
  DALu81 - 49.3121370972651 <= 0;
subject to dalu91:
  DALu91 - 1175.38776952941 <= 0;
subject to dalu101:
  DALu101 - 14.2975580197957 <= 0;
subject to alu_subtotal1:
  DALu11 >= DALu12 + DALu13 + DALu14 + DALu15 + DALu16;
subject to alu_subtotal2:
  DALu21 >= DALu22 + DALu23 + DALu24 + DALu25 + DALu26;
subject to alu_subtotal3:
  DALu31 >= DALu32 + DALu33 + DALu34 + DALu35 + DALu36;
subject to alu_subtotal4:
  DALu41 >= DALu42 + DALu43 + DALu44 + DALu45 + DALu46;
subject to alu_subtotal5:
  DALu51 >= DALu52 + DALu53 + DALu54 + DALu55 + DALu56;
subject to alu_subtotal6:
  DALu61 >= DALu62 + DALu63 + DALu64 + DALu65 + DALu66;
subject to alu_subtotal7:
  DALu71 >= DALu72 + DALu73 + DALu74 + DALu75 + DALu76;
subject to alu_subtotal8:
  DALu81 >= DALu82 + DALu83 + DALu84 + DALu85 + DALu86;
subject to alu_subtotal9:
  DALu91 >= DALu92 + DALu93 + DALu94 + DALu95 + DALu96;
subject to alu_subtotal10:
  DALu101 >= DALu102 + DALu103 + DALu104 + DALu105 + DALu106;
subject to alu_excl92:
  DALu92 = 0;
subject to alu_excl93:
  DALu93 = 0;
subject to alu_excl94:
  DALu94 = 0;
subject to alu_excl95:
  DALu95 = 0;
subject to alu_excl96:
  DALu96 = 0;
subject to alu_excl102:
  DALu102 = 0;
subject to alu_excl103:
  DALu103 = 0;
subject to alu_excl104:
  DALu104 = 0;
subject to alu_excl105:
  DALu105 = 0;
subject to alu_excl106:
  DALu106 = 0;
